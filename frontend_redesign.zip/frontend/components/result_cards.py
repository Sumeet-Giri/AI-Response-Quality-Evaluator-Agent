import streamlit as st
from components.score_ring import render_score_ring
from components.badges import badge_html, card_open, card_close, section_label


def relevance_card(data: dict):
    card_open("card-hover")
    section_label("Relevance Agent")
    c1, c2 = st.columns([1, 2])
    with c1:
        render_score_ring(data.get("score", 0), "Relevance Score", key="ring_relevance")
    with c2:
        sim = data.get("semantic_similarity", 0)
        match = data.get("topic_match", False)
        st.markdown(
            badge_html("Topic Match ✓" if match else "Topic Mismatch", "good" if match else "bad"),
            unsafe_allow_html=True,
        )
        st.progress(min(1.0, sim), text=f"Semantic Similarity: {sim:.2f}")
        with st.expander("Reasoning"):
            st.write(data.get("reasoning", "—"))
    card_close()


def accuracy_card(data: dict):
    card_open("card-hover")
    section_label("Accuracy Agent")
    c1, c2 = st.columns([1, 2])
    with c1:
        render_score_ring(data.get("score", 0), "Accuracy Score", key="ring_accuracy")
    with c2:
        correct = data.get("factually_correct", False)
        st.markdown(
            badge_html("Factually Correct ✓" if correct else "Factual Issues Found",
                       "good" if correct else "bad"),
            unsafe_allow_html=True,
        )
        sim = data.get("semantic_similarity", 0)
        st.progress(min(1.0, sim), text=f"Semantic Similarity: {sim:.2f}")
        evidence = data.get("evidence", [])
        if evidence:
            st.caption("Evidence")
            for e in evidence:
                st.markdown(f"- {e}")
        with st.expander("Reasoning"):
            st.write(data.get("reasoning", "—"))
    card_close()


def hallucination_card(data: dict):
    card_open("card-hover")
    section_label("Hallucination Detection Agent")
    c1, c2 = st.columns([1, 2])
    with c1:
        render_score_ring(data.get("score", 0), "Hallucination-Free Score", key="ring_hallucination")
    with c2:
        hallucinated = data.get("hallucinated_claims", [])
        risk_kind = "good" if not hallucinated else ("warn" if len(hallucinated) == 1 else "bad")
        risk_label = "Low Risk" if not hallucinated else f"{len(hallucinated)} Unsupported Claim(s)"
        st.markdown(badge_html(risk_label, risk_kind), unsafe_allow_html=True)

        supported = data.get("supported_claims", [])
        colA, colB = st.columns(2)
        with colA:
            st.caption(f"✅ Supported Claims ({len(supported)})")
            for c in supported:
                st.markdown(f"- {c}")
        with colB:
            st.caption(f"⚠️ Hallucinated Claims ({len(hallucinated)})")
            if hallucinated:
                for c in hallucinated:
                    st.markdown(f"- {c}")
            else:
                st.markdown("_None detected_")
        with st.expander("Reasoning"):
            st.write(data.get("reasoning", "—"))
    card_close()


def completeness_card(data: dict):
    card_open("card-hover")
    section_label("Completeness Agent")
    c1, c2 = st.columns([1, 2])
    with c1:
        render_score_ring(data.get("score", 0), "Completeness Score", key="ring_completeness")
    with c2:
        coverage = data.get("coverage_percentage", 0)
        st.progress(min(1.0, coverage / 100), text=f"Coverage: {coverage:.1f}%  "
                                                     f"({len(data.get('covered_aspects', []))}/"
                                                     f"{data.get('total_aspects', 0)} aspects)")
        colA, colB = st.columns(2)
        with colA:
            st.caption("Covered Aspects")
            for a in data.get("covered_aspects", []):
                st.markdown(f"- {a}")
        with colB:
            st.caption("Missing Aspects")
            missing = data.get("missing_aspects", [])
            if missing:
                for a in missing:
                    st.markdown(f"- {a}")
            else:
                st.markdown("_None — fully covered_")
        with st.expander("Reasoning"):
            st.write(data.get("reasoning", "—"))
    card_close()


def verdict_card(data: dict):
    card_open("card-hover")
    section_label("Verdict Agent — Final Evaluation")
    c1, c2 = st.columns([1, 2])
    with c1:
        render_score_ring(data.get("overall_score", 0), "Overall Score", key="ring_verdict", size=210)
        gate = data.get("quality_gate_passed", False)
        st.markdown(
            f"<div style='text-align:center;margin-top:6px'>"
            f"{badge_html(data.get('final_verdict','—'), 'good' if gate else 'bad')}"
            f"</div>",
            unsafe_allow_html=True,
        )
    with c2:
        colA, colB = st.columns(2)
        with colA:
            st.caption("💪 Strengths")
            for s in data.get("strengths", []):
                st.markdown(f"- {s}")
        with colB:
            st.caption("⚠️ Weaknesses")
            weak = data.get("weaknesses", [])
            if weak:
                for w in weak:
                    st.markdown(f"- {w}")
            else:
                st.markdown("_None identified_")
        with st.expander("Consolidated Reasoning", expanded=True):
            st.write(data.get("consolidated_reasoning", "—"))
    card_close()
