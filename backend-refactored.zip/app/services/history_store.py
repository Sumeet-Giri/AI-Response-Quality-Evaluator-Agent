"""
Evaluation History Store (SQLite)
-----------------------------------
Persists every evaluation (single or batch) so the Milestone 4 Dashboard
can show real trends across runs, not just the current browser session.

This was the one genuine gap blocking the Dashboard: before this file
existed, batch results lived only in Streamlit's st.session_state --
gone on refresh, invisible across sessions, and impossible to compare
"AI System A" against "AI System B" over time. This is the fix.

Design notes:
- Uses stdlib sqlite3 only -- no new dependency, matches the originally
  scoped tech stack (SQLite for persistence) without adding an ORM.
- One flat table (`evaluation_records`) covers both single evaluations
  (batch_id is NULL) and batch rows (batch_id groups rows from one CSV
  run together) -- this keeps querying simple: "all history" and "one
  batch" are both just filters on the same table, not a join.
- A short-lived connection is opened per call rather than held globally.
  FastAPI runs sync route handlers in a threadpool, and sqlite3
  connections aren't safe to share across threads by default -- opening
  per call sidesteps that entirely and is more than fast enough at this
  project's scale (this is not a high-throughput production service).
- Every write is wrapped so a persistence failure (disk full, locked db,
  etc.) NEVER breaks an evaluation request -- recording history is a
  side effect of evaluating, not a precondition for it. See
  record_evaluation()'s try/except.
"""

import sqlite3
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

DB_PATH = Path(__file__).resolve().parent.parent.parent / "evaluation_history.db"

_SCHEMA = """
CREATE TABLE IF NOT EXISTS evaluation_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at TEXT NOT NULL,
    mode TEXT NOT NULL,                 -- 'single' or 'batch'
    batch_id TEXT,                      -- NULL for single evaluations
    batch_label TEXT,                   -- optional human label for the batch run
    system_name TEXT NOT NULL DEFAULT 'Unspecified',  -- which AI system produced the response
    question TEXT NOT NULL,
    response TEXT NOT NULL,
    reference_answer TEXT,
    rag_source TEXT,                    -- 'user_supplied' | 'retrieved' | 'none'
    relevance_score REAL,
    accuracy_score REAL,
    hallucination_score REAL,
    completeness_score REAL,
    overall_score REAL,
    final_verdict TEXT,
    quality_gate_passed INTEGER         -- 0 or 1
);
CREATE INDEX IF NOT EXISTS idx_batch_id ON evaluation_records(batch_id);
CREATE INDEX IF NOT EXISTS idx_system_name ON evaluation_records(system_name);
CREATE INDEX IF NOT EXISTS idx_created_at ON evaluation_records(created_at);
"""


@contextmanager
def _connect():
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    # Idempotent -- cheap enough to run on every connection, and removes
    # an entire class of "forgot to call init_db() first" bugs. The
    # startup event in main.py still calls init_db() explicitly too, but
    # this module no longer depends on that having happened.
    conn.executescript(_SCHEMA)
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db():
    """Creates the table/indexes if they don't exist yet. Called once at
    app startup (see main.py) -- idempotent, safe to call every time."""
    with _connect() as conn:
        conn.executescript(_SCHEMA)


def new_batch_id() -> str:
    """Called once per batch run by the frontend/caller, then passed on
    every row's evaluation so they're grouped together in history."""
    return uuid.uuid4().hex[:12]


def record_evaluation(
    *,
    mode: str,
    question: str,
    response: str,
    reference_answer: str,
    rag_source: str,
    relevance_score,
    accuracy_score,
    hallucination_score,
    completeness_score,
    overall_score,
    final_verdict: str,
    quality_gate_passed: bool,
    system_name: str = "Unspecified",
    batch_id: Optional[str] = None,
    batch_label: Optional[str] = None,
) -> None:
    """
    Persists one evaluation result. Called by EvaluationOrchestrator after
    every /evaluate/all (and therefore every /evaluate/verdict, since that
    delegates to run_all internally) -- recording is automatic, not
    something the frontend has to remember to do separately.

    Deliberately never raises: a persistence failure must never break an
    evaluation response. Best-effort, logged, swallowed.
    """
    try:
        with _connect() as conn:
            conn.execute(
                """
                INSERT INTO evaluation_records (
                    created_at, mode, batch_id, batch_label, system_name,
                    question, response, reference_answer, rag_source,
                    relevance_score, accuracy_score, hallucination_score,
                    completeness_score, overall_score, final_verdict,
                    quality_gate_passed
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    datetime.now(timezone.utc).isoformat(),
                    mode,
                    batch_id,
                    batch_label,
                    system_name or "Unspecified",
                    question,
                    response,
                    reference_answer,
                    rag_source,
                    relevance_score,
                    accuracy_score,
                    hallucination_score,
                    completeness_score,
                    overall_score,
                    final_verdict,
                    1 if quality_gate_passed else 0,
                ),
            )
    except Exception:
        # Best-effort by design -- see docstring. If this matters enough
        # to alert on later, hook a logger in here; it must never re-raise.
        pass


# --------------------------------------------------------------------
# Read-side queries, used by the Dashboard API endpoints
# --------------------------------------------------------------------

def get_runs(
    system_name: Optional[str] = None,
    batch_id: Optional[str] = None,
    mode: Optional[str] = None,
    limit: int = 500,
) -> list[dict]:
    query = "SELECT * FROM evaluation_records WHERE 1=1"
    params: list = []
    if system_name:
        query += " AND system_name = ?"
        params.append(system_name)
    if batch_id:
        query += " AND batch_id = ?"
        params.append(batch_id)
    if mode:
        query += " AND mode = ?"
        params.append(mode)
    query += " ORDER BY created_at DESC LIMIT ?"
    params.append(limit)

    with _connect() as conn:
        rows = conn.execute(query, params).fetchall()
        return [dict(r) for r in rows]


def get_overall_summary() -> dict:
    with _connect() as conn:
        row = conn.execute(
            """
            SELECT
                COUNT(*) AS total_evaluations,
                AVG(overall_score) AS avg_overall_score,
                AVG(relevance_score) AS avg_relevance,
                AVG(accuracy_score) AS avg_accuracy,
                AVG(hallucination_score) AS avg_hallucination,
                AVG(completeness_score) AS avg_completeness,
                SUM(CASE WHEN quality_gate_passed = 1 THEN 1 ELSE 0 END) AS total_pass,
                SUM(CASE WHEN quality_gate_passed = 0 THEN 1 ELSE 0 END) AS total_fail,
                SUM(CASE WHEN hallucination_score < 4 THEN 1 ELSE 0 END) AS high_hallucination_count
            FROM evaluation_records
            """
        ).fetchone()
        return dict(row) if row else {}


def get_batch_summaries(limit: int = 100) -> list[dict]:
    """One row per distinct batch run, most recent first -- this is the
    "quality trends across batch evaluations" data source."""
    with _connect() as conn:
        rows = conn.execute(
            """
            SELECT
                batch_id,
                MAX(batch_label) AS batch_label,
                MAX(system_name) AS system_name,
                MIN(created_at) AS started_at,
                COUNT(*) AS row_count,
                AVG(overall_score) AS avg_overall_score,
                AVG(relevance_score) AS avg_relevance,
                AVG(accuracy_score) AS avg_accuracy,
                AVG(hallucination_score) AS avg_hallucination,
                AVG(completeness_score) AS avg_completeness,
                SUM(CASE WHEN quality_gate_passed = 1 THEN 1 ELSE 0 END) AS pass_count,
                SUM(CASE WHEN quality_gate_passed = 0 THEN 1 ELSE 0 END) AS fail_count
            FROM evaluation_records
            WHERE mode = 'batch' AND batch_id IS NOT NULL
            GROUP BY batch_id
            ORDER BY started_at DESC
            LIMIT ?
            """,
            (limit,),
        ).fetchall()
        return [dict(r) for r in rows]


def get_system_summaries() -> list[dict]:
    """One row per distinct system_name -- the data source for comparing
    two (or more) AI systems side by side."""
    with _connect() as conn:
        rows = conn.execute(
            """
            SELECT
                system_name,
                COUNT(*) AS total_evaluations,
                AVG(overall_score) AS avg_overall_score,
                AVG(relevance_score) AS avg_relevance,
                AVG(accuracy_score) AS avg_accuracy,
                AVG(hallucination_score) AS avg_hallucination,
                AVG(completeness_score) AS avg_completeness,
                SUM(CASE WHEN quality_gate_passed = 1 THEN 1 ELSE 0 END) AS pass_count,
                SUM(CASE WHEN quality_gate_passed = 0 THEN 1 ELSE 0 END) AS fail_count
            FROM evaluation_records
            GROUP BY system_name
            ORDER BY total_evaluations DESC
            """
        ).fetchall()
        return [dict(r) for r in rows]


def clear_all():
    """Testing/demo-reset helper -- not exposed over the API by default."""
    with _connect() as conn:
        conn.execute("DELETE FROM evaluation_records")
